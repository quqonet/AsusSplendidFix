using System;
using System.Diagnostics;
using System.IO;
using System.Threading;
using System.Windows.Forms;
using Microsoft.Win32;

namespace SplendidWakeFix
{
    static class Program
    {
        private static readonly string LogFile = Path.Combine(AppDomain.CurrentDomain.BaseDirectory, "log.txt");
        private static readonly string SplendidDir = @"C:\ProgramData\ASUS\ASUS System Control Interface\ASUSOptimization\Splendid";

        private static long _lastTriggerTicks = 0;
        private static readonly object _lock = new object();

        [STAThread]
        static void Main(string[] args)
        {
            if (args.Length > 0 && args[0].Equals("--trigger", StringComparison.OrdinalIgnoreCase))
            {
                ApplySplendid("Manual Trigger");
                return;
            }

            bool createdNew;
            using (var mutex = new Mutex(true, "SplendidWakeFix_SingleInstanceMutex", out createdNew))
            {
                if (!createdNew)
                {
                    return; // Already running
                }

                Log("SplendidWakeFix background service started.");

                SystemEvents.PowerModeChanged += (s, e) =>
                {
                    if (e.Mode == PowerModes.Resume)
                    {
                        ScheduleApply("Resume from Sleep", 2000);
                    }
                };

                SystemEvents.SessionSwitch += (s, e) =>
                {
                    if (e.Reason == SessionSwitchReason.SessionUnlock || e.Reason == SessionSwitchReason.ConsoleConnect)
                    {
                        ScheduleApply("Session Unlock", 1500);
                    }
                };

                Application.Run();
            }
        }

        private static void ScheduleApply(string reason, int delayMs)
        {
            lock (_lock)
            {
                long now = DateTime.UtcNow.Ticks;
                // Cooldown of 4 seconds between triggers to prevent duplicate runs
                if (now - _lastTriggerTicks < TimeSpan.FromSeconds(4).Ticks)
                {
                    return;
                }
                _lastTriggerTicks = now;
            }

            ThreadPool.QueueUserWorkItem(_ =>
            {
                try
                {
                    Thread.Sleep(delayMs);
                    ApplySplendid(reason);
                }
                catch (Exception ex)
                {
                    Log("Error in ScheduleApply: " + ex.Message);
                }
            });
        }

        private static string FindIniPath()
        {
            try
            {
                // 1. Try current logged-in user's specific .sys file
                string userSpecific = Path.Combine(SplendidDir, Environment.UserName + "_my_sp_data.sys");
                if (File.Exists(userSpecific)) return userSpecific;

                // 2. Try any *_my_sp_data.sys file in the Splendid directory
                if (Directory.Exists(SplendidDir))
                {
                    var files = Directory.GetFiles(SplendidDir, "*_my_sp_data.sys");
                    if (files.Length > 0) return files[0];
                }
            }
            catch
            {
            }

            return null;
        }

        private static string FindExePath(string fromIni)
        {
            try
            {
                if (!string.IsNullOrEmpty(fromIni) && File.Exists(fromIni))
                {
                    return fromIni;
                }

                // Fallback: search Windows DriverStore for AsusSplendid.exe
                string driverStore = Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.Windows), "System32", "DriverStore", "FileRepository");
                if (Directory.Exists(driverStore))
                {
                    var candidates = Directory.GetDirectories(driverStore, "asussci2.inf_amd64_*");
                    foreach (var dir in candidates)
                    {
                        string target = Path.Combine(dir, "ASUSOptimization", "AsusSplendid.exe");
                        if (File.Exists(target)) return target;
                    }
                }
            }
            catch
            {
            }

            return null;
        }

        private static void ApplySplendid(string triggerSource)
        {
            try
            {
                string iniPath = FindIniPath();
                string exePath = null;
                string mode = "1"; // Default: Normal mode

                if (iniPath != null && File.Exists(iniPath))
                {
                    var lines = File.ReadAllLines(iniPath);
                    foreach (var line in lines)
                    {
                        if (line.StartsWith("ExePath=", StringComparison.OrdinalIgnoreCase))
                        {
                            exePath = line.Substring(8).Trim();
                        }
                        else if (line.StartsWith("Mode=", StringComparison.OrdinalIgnoreCase))
                        {
                            string m = line.Substring(5).Trim();
                            if (!string.IsNullOrEmpty(m)) mode = m;
                        }
                    }
                }

                exePath = FindExePath(exePath);

                if (string.IsNullOrEmpty(exePath) || !File.Exists(exePath))
                {
                    Log("AsusSplendid.exe could not be located on the system.");
                    return;
                }

                var psi = new ProcessStartInfo
                {
                    FileName = exePath,
                    Arguments = mode + " 0",
                    WorkingDirectory = Path.GetDirectoryName(exePath),
                    CreateNoWindow = true,
                    UseShellExecute = false,
                    WindowStyle = ProcessWindowStyle.Hidden
                };

                using (var proc = Process.Start(psi))
                {
                    if (proc != null)
                    {
                        proc.WaitForExit(6000);
                        Log(string.Format("[{0}] Successfully re-applied Splendid (Mode={1}) via {2}", triggerSource, mode, Path.GetFileName(exePath)));
                    }
                }
            }
            catch (Exception ex)
            {
                Log(string.Format("[{0}] Exception while applying Splendid: {1}", triggerSource, ex.Message));
            }
        }

        private static void Log(string message)
        {
            try
            {
                string line = string.Format("[{0:yyyy-MM-dd HH:mm:ss}] {1}", DateTime.Now, message);
                File.AppendAllText(LogFile, line + Environment.NewLine);
            }
            catch
            {
            }
        }
    }
}

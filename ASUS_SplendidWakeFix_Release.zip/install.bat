@echo off
setlocal
echo ========================================================
echo   ASUS Splendid Wake Fix - Installer
echo ========================================================
echo.

set "TARGET_DIR=%LOCALAPPDATA%\ASUS_SplendidFix"
set "EXE_NAME=SplendidWakeFix.exe"

if not exist "%TARGET_DIR%" (
    mkdir "%TARGET_DIR%"
)

echo [*] Copying files to %TARGET_DIR%...
copy /Y "%~dp0%EXE_NAME%" "%TARGET_DIR%\%EXE_NAME%" >nul
if errorlevel 1 (
    echo [!] Failed to copy %EXE_NAME%. Make sure the file exists in this directory.
    pause
    exit /b 1
)

if exist "%~dp0SplendidWakeFix.cs" (
    copy /Y "%~dp0SplendidWakeFix.cs" "%TARGET_DIR%\" >nul
)

echo [*] Registering in Windows Startup (CurrentUser)...
reg add "HKCU\Software\Microsoft\Windows\CurrentVersion\Run" /v "ASUS_SplendidWakeFix" /t REG_SZ /d "\"%TARGET_DIR%\%EXE_NAME%\"" /f >nul
if errorlevel 1 (
    echo [!] Failed to add registry startup entry.
    pause
    exit /b 1
)

echo [*] Stopping any running instance...
taskkill /f /im %EXE_NAME% 2>nul

echo [*] Starting background service...
start "" "%TARGET_DIR%\%EXE_NAME%"

echo.
echo ========================================================
echo  [SUCCESS] ASUS Splendid Wake Fix is now installed!
echo  It will run silently in the background and restore
echo  your Splendid profile every time the laptop wakes up.
echo ========================================================
echo.
pause

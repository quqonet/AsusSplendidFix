@echo off
setlocal
echo ========================================================
echo   ASUS Splendid Wake Fix - Uninstaller
echo ========================================================
echo.

set "TARGET_DIR=%LOCALAPPDATA%\ASUS_SplendidFix"
set "EXE_NAME=SplendidWakeFix.exe"

echo [*] Stopping running background process...
taskkill /f /im %EXE_NAME% 2>nul

echo [*] Removing registry startup entry...
reg delete "HKCU\Software\Microsoft\Windows\CurrentVersion\Run" /v "ASUS_SplendidWakeFix" /f 2>nul

if exist "%TARGET_DIR%" (
    echo [*] Removing installation directory: %TARGET_DIR%...
    rmdir /s /q "%TARGET_DIR%" 2>nul
)

echo.
echo ========================================================
echo  [SUCCESS] ASUS Splendid Wake Fix has been uninstalled.
echo ========================================================
echo.
pause
